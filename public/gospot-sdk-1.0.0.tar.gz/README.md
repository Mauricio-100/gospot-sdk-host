GoSpot SDK
Contains scripts: ssh.sh, tools.sh, admin.sh
