#!/bin/sh
# sample server script - start hotspot/ssh placeholder
set -eu
echo "[gospot] This is a placeholder server script. Implement server logic here."
echo "[gospot] To provide connections, ensure sshd is runnable and hotspot enabled on device."
