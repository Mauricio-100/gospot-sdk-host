#!/bin/sh
set -eu
echo "[SDK] tools.sh exécuté"
# Ici mets les étapes d'installation pour le SDK (scripts séparés)
