#!/bin/sh
set -eu
echo "[SDK] admin tools"
uname -a
df -h
