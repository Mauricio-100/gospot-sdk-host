#!/bin/sh
set -eu
KEY="$HOME/.ssh/gospot_key"
if [ -f "$KEY" ]; then
  echo "[*] Clé existante : $KEY"
  cat "${KEY}.pub" || true
else
  mkdir -p "$(dirname "$KEY")"
  ssh-keygen -t ed25519 -f "$KEY" -N "" 2>/dev/null || ssh-keygen -t rsa -b 4096 -f "$KEY" -N ""
  echo "[*] Clé créée : $KEY"
  cat "${KEY}.pub"
fi
